manitaya yollamalık sadece arkada kısa bir python kodunu calıstıran kod opensourceyi bıraktım kendinizde yapabilirsiniz yada direkt exeyi indirtin
